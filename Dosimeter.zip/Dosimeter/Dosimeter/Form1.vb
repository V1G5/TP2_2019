﻿Imports System
Imports System.Threading
Imports System.IO.Ports
Imports System.ComponentModel

Public Class Form1
    'Stores results for calculation of skin type
    Private m_IntQ1_ans As Integer
    Private m_IntQ2_ans As Integer
    Private m_IntQ3_ans As Integer
    Private m_IntQ4_ans As Integer
    Private m_IntQ5_ans As Integer
    Private m_IntQ6_ans As Integer
    Private m_IntQ7_ans As Integer
    Private m_IntQ8_ans As Integer
    Private m_IntQ9_ans As Integer
    Private m_IntQ10_ans As Integer

    Private test As String

    'Stores results
    Private m_IntResult As Integer
    Private m_StrResult As String
    Private m_IntMED As Integer
    Private m_strSED As String = "0"

    'Stores MED Flag
    Private m_IntMEDFlag As Integer = 0

    'Stores date and time
    Private m_strTimeDate

    'Stores COM Ports
    Private m_Ports As Array
    Delegate Sub SetTextCallBack(ByVal [text] As String)

    Private Sub CboQ1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ1.SelectedIndexChanged
        'Get answer for Q1 Fitzpatrick quiz
        If (cboQ1.SelectedItem = "Light blue or green, grey") Then
            m_IntQ1_ans = 0
        ElseIf (cboQ1.SelectedItem = "Blue, green, grey") Then
            m_IntQ1_ans = 1
        ElseIf (cboQ1.SelectedItem = "Dark blue or green, light brown (hazel)") Then
            m_IntQ1_ans = 2
        ElseIf (cboQ1.SelectedItem = "Dark brown") Then
            m_IntQ1_ans = 3
        ElseIf (cboQ1.SelectedItem = "Brownish black") Then
            m_IntQ1_ans = 4
        End If

    End Sub

    Private Sub CboQ2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ2.SelectedIndexChanged
        'Get answer for Q2 Fitzpatrick quiz

        If (cboQ2.SelectedItem = "Red") Then
            m_IntQ2_ans = 0
        ElseIf (cboQ2.SelectedItem = "Blonde") Then
            m_IntQ2_ans = 1
        ElseIf (cboQ2.SelectedItem = "Chestnut or dark blonde") Then
            m_IntQ2_ans = 2
        ElseIf (cboQ2.SelectedItem = "Dark brown") Then
            m_IntQ2_ans = 3
        ElseIf (cboQ2.SelectedItem = "Black") Then
            m_IntQ2_ans = 4
        End If

    End Sub

    Private Sub CboQ3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ3.SelectedIndexChanged
        'Get answer for Q3 Fitzpatrick quiz

        If (cboQ3.SelectedItem = "Pink") Then
            m_IntQ3_ans = 0
        ElseIf (cboQ3.SelectedItem = "Very Pale") Then
            m_IntQ3_ans = 1
        ElseIf (cboQ3.SelectedItem = "Light brown or olive") Then
            m_IntQ3_ans = 2
        ElseIf (cboQ3.SelectedItem = "Brown") Then
            m_IntQ3_ans = 3
        ElseIf (cboQ3.SelectedItem = "Dark brown") Then
            m_IntQ3_ans = 4
        End If

    End Sub

    Private Sub CboQ4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ4.SelectedIndexChanged
        'Get answer for Q4 Fitzpatrick quiz

        If (cboQ4.SelectedItem = "Many") Then
            m_IntQ4_ans = 0
        ElseIf (cboQ4.SelectedItem = "Several") Then
            m_IntQ4_ans = 1
        ElseIf (cboQ4.SelectedItem = "Few") Then
            m_IntQ4_ans = 2
        ElseIf (cboQ4.SelectedItem = "Rare") Then
            m_IntQ4_ans = 3
        ElseIf (cboQ4.SelectedItem = "None") Then
            m_IntQ4_ans = 4
        End If

    End Sub

    Private Sub CboQ5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ5.SelectedIndexChanged
        'Get answer for Q5 Fitzpatrick quiz

        If (cboQ5.SelectedItem = "Severe burns, blistering, peeling") Then
            m_IntQ5_ans = 0
        ElseIf (cboQ5.SelectedItem = "Moderate burns, blistering, peeling") Then
            m_IntQ5_ans = 1
        ElseIf (cboQ5.SelectedItem = "Burns sometimes followed by peeling") Then
            m_IntQ5_ans = 2
        ElseIf (cboQ5.SelectedItem = "Rare burns") Then
            m_IntQ5_ans = 3
        ElseIf (cboQ5.SelectedItem = "No burns") Then
            m_IntQ5_ans = 4
        End If

    End Sub

    Private Sub CboQ6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ6.SelectedIndexChanged
        'Get answer for Q6 Fitzpatrick quiz

        If (cboQ6.SelectedItem = "Never") Then
            m_IntQ6_ans = 0
        ElseIf (cboQ6.SelectedItem = "Rarely") Then
            m_IntQ6_ans = 1
        ElseIf (cboQ6.SelectedItem = "Sometimes") Then
            m_IntQ6_ans = 2
        ElseIf (cboQ6.SelectedItem = "Often") Then
            m_IntQ6_ans = 3
        ElseIf (cboQ6.SelectedItem = "Always") Then
            m_IntQ6_ans = 4
        End If

    End Sub

    Private Sub CboQ7_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ7.SelectedIndexChanged
        'Get answer for Q7 Fitzpatrick quiz

        If (cboQ7.SelectedItem = "Hardly or not at all") Then
            m_IntQ7_ans = 0
        ElseIf (cboQ7.SelectedItem = "Light tan") Then
            m_IntQ7_ans = 1
        ElseIf (cboQ7.SelectedItem = "Medium tan") Then
            m_IntQ7_ans = 2
        ElseIf (cboQ7.SelectedItem = "Dark tan") Then
            m_IntQ7_ans = 3
        ElseIf (cboQ7.SelectedItem = "Very dark tan") Then
            m_IntQ7_ans = 4
        End If

    End Sub

    Private Sub CboQ8_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ8.SelectedIndexChanged
        'Get answer for Q8 Fitzpatrick quiz

        If (cboQ8.SelectedItem = "Very sensitive") Then
            m_IntQ8_ans = 0
        ElseIf (cboQ8.SelectedItem = "Sensitive") Then
            m_IntQ8_ans = 1
        ElseIf (cboQ8.SelectedItem = "Mildly sensitive") Then
            m_IntQ8_ans = 2
        ElseIf (cboQ8.SelectedItem = "Resistant") Then
            m_IntQ8_ans = 3
        ElseIf (cboQ8.SelectedItem = "Very resistant") Then
            m_IntQ8_ans = 4
        End If

    End Sub

    Private Sub CboQ9_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ9.SelectedIndexChanged
        'Get answer for Q9 Fitzpatrick quiz

        If (cboQ9.SelectedItem = "Never") Then
            m_IntQ9_ans = 0
        ElseIf (cboQ9.SelectedItem = "Rarely") Then
            m_IntQ9_ans = 1
        ElseIf (cboQ9.SelectedItem = "Sometimes") Then
            m_IntQ9_ans = 2
        ElseIf (cboQ9.SelectedItem = "Often") Then
            m_IntQ9_ans = 3
        ElseIf (cboQ9.SelectedItem = "Always") Then
            m_IntQ9_ans = 4
        End If

    End Sub

    Private Sub CboQ10_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ10.SelectedIndexChanged
        'Get answer for Q10 Fitzpatrick quiz

        If (cboQ10.SelectedItem = "More than 3 months ago") Then
            m_IntQ10_ans = 0
        ElseIf (cboQ10.SelectedItem = "In the last 2-3 months") Then
            m_IntQ10_ans = 1
        ElseIf (cboQ10.SelectedItem = "In the last 1-2 months") Then
            m_IntQ10_ans = 2
        ElseIf (cboQ10.SelectedItem = "In the last week") Then
            m_IntQ10_ans = 3
        ElseIf (cboQ10.SelectedItem = "In the last day") Then
            m_IntQ10_ans = 4
        End If

    End Sub

    Private Sub SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboQ1.SelectedIndexChanged, cboQ2.SelectedIndexChanged,
    cboQ3.SelectedIndexChanged, cboQ4.SelectedIndexChanged, cboQ5.SelectedIndexChanged, cboQ6.SelectedIndexChanged, cboQ7.SelectedIndexChanged,
    cboQ8.SelectedIndexChanged, cboQ9.SelectedIndexChanged, cboQ10.SelectedIndexChanged
        'Re-enables result button
        If (Not String.IsNullOrEmpty(cboQ1.Text)) And (Not String.IsNullOrEmpty(cboQ2.Text)) And (Not String.IsNullOrEmpty(cboQ3.Text)) _
        And (Not String.IsNullOrEmpty(cboQ4.Text)) And (Not String.IsNullOrEmpty(cboQ5.Text)) And (Not String.IsNullOrEmpty(cboQ6.Text)) _
        And (Not String.IsNullOrEmpty(cboQ7.Text)) And (Not String.IsNullOrEmpty(cboQ8.Text)) And (Not String.IsNullOrEmpty(cboQ9.Text)) _
        And (Not String.IsNullOrEmpty(cboQ10.Text)) Then
            btnResult.Enabled = True
        End If
    End Sub


    Private Sub BtnResult_Click(sender As Object, e As EventArgs) Handles btnResult.Click
        'Calculate result of Fitzpatrick quiz and display result when pressed, enable reset button
        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
        btnResult.Enabled = False

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False
        m_IntMEDFlag = 0

        m_IntResult = m_IntQ1_ans + m_IntQ2_ans + m_IntQ3_ans + m_IntQ4_ans + m_IntQ5_ans +
            m_IntQ6_ans + m_IntQ7_ans + m_IntQ8_ans + m_IntQ9_ans + m_IntQ10_ans

        If (m_IntResult >= 0 And m_IntResult <= 6) Then
            m_StrResult = "1"
            m_IntMED = 150
        ElseIf (m_IntResult >= 7 And m_IntResult <= 13) Then
            m_StrResult = "2"
            m_IntMED = 220
        ElseIf (m_IntResult >= 14 And m_IntResult <= 20) Then
            m_StrResult = "3"
            m_IntMED = 290
        ElseIf (m_IntResult >= 21 And m_IntResult <= 27) Then
            m_StrResult = "4"
            m_IntMED = 370
        ElseIf (m_IntResult >= 28 And m_IntResult <= 34) Then
            m_StrResult = "5"
            m_IntMED = 440
        ElseIf (m_IntResult >= 35) Then
            m_StrResult = "6"
            m_IntMED = 440
        End If

        lblSum.Text = m_StrResult
        lblMED.Text = m_IntMED & m_IntMEDFlag

    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'Resets form
        lblSum.Text = ""
        lblMED.Text = ""
        m_StrResult = ""

        btnResult.Enabled = False
        btnReset.Enabled = False
        btnMEDOvr.Enabled = False

        chkTypeI.Enabled = True
        chkTypeII.Enabled = True
        chkTypeIII.Enabled = True
        chkTypeIV.Enabled = True
        chkTypeV.Enabled = True
        chkTypeVI.Enabled = True

        chkTypeI.Enabled = True
        chkTypeII.Enabled = True
        chkTypeIII.Enabled = True
        chkTypeIV.Enabled = True
        chkTypeV.Enabled = True
        chkTypeVI.Enabled = True

        chkTypeI.Checked = False
        chkTypeII.Checked = False
        chkTypeIII.Checked = False
        chkTypeIV.Checked = False
        chkTypeV.Checked = False
        chkTypeVI.Checked = False

        cboQ1.SelectedIndex = -1
        cboQ2.SelectedIndex = -1
        cboQ3.SelectedIndex = -1
        cboQ4.SelectedIndex = -1
        cboQ5.SelectedIndex = -1
        cboQ6.SelectedIndex = -1
        cboQ7.SelectedIndex = -1
        cboQ8.SelectedIndex = -1
        cboQ9.SelectedIndex = -1
        cboQ10.SelectedIndex = -1
    End Sub

    Private Sub chkTypeI_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeI.Click
        'Allows override of quiz

        If (chkTypeI.Checked = True) Then
            m_StrResult = "1"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 150
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True

    End Sub

    Private Sub chkTypeII_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeII.Click
        'Allows override of quiz

        If (chkTypeII.Checked = True) Then
            m_StrResult = "2"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 220
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
    End Sub

    Private Sub chkTypeIII_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeIII.Click
        'Allows override of quiz

        If (chkTypeIII.Checked = True) Then
            m_StrResult = "3"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 290
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
    End Sub

    Private Sub chkTypeIV_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeIV.Click
        'Allows override of quiz

        If (chkTypeIV.Checked = True) Then
            m_StrResult = "4"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 370
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
    End Sub

    Private Sub chkTypeV_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeV.Click
        'Allows override of quiz

        If (chkTypeV.Checked = True) Then
            m_StrResult = "5"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 440
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
    End Sub

    Private Sub chkTypeVI_CheckStateChanged(sender As Object, e As EventArgs) Handles chkTypeVI.Click
        'Allows override of quiz

        If (chkTypeVI.Checked = True) Then
            m_StrResult = "6"
            m_IntMEDFlag = 0
            lblSum.Text = m_StrResult
            m_IntMED = 440
            lblMED.Text = m_IntMED & m_IntMEDFlag
        End If

        chkTypeI.Enabled = False
        chkTypeII.Enabled = False
        chkTypeIII.Enabled = False
        chkTypeIV.Enabled = False
        chkTypeV.Enabled = False
        chkTypeVI.Enabled = False

        btnReset.Enabled = True
        btnMEDOvr.Enabled = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Disables buttons on load

        btnResult.Enabled = False
        btnReset.Enabled = False
        btnMEDOvr.Enabled = False


        btnClose.Enabled = False

    End Sub

    'Handles serial port connection
    Private Sub BtnInit_Click(sender As Object, e As EventArgs) Handles btnInit.Click
        If (Not String.IsNullOrEmpty(cboCOM.Text)) And (Not String.IsNullOrEmpty(cboBaud.Text)) Then
            SerialPort1.PortName = cboCOM.Text
            SerialPort1.BaudRate = cboBaud.Text
            SerialPort1.Open()
            btnInit.Enabled = False

            btnClose.Enabled = True
            'GC.SuppressFinalize(SerialPort1.BaseStream)
        End If
    End Sub
    Private Sub CboCOM_DropDown(sender As Object, e As EventArgs) Handles cboCOM.DropDown
        m_Ports = IO.Ports.SerialPort.GetPortNames()
        For i As Integer = 0 To m_Ports.GetUpperBound(0)
            If Not cboCOM.Items.Contains(m_Ports(i)) Then
                cboCOM.Items.AddRange(m_Ports)
            End If
        Next
    End Sub



    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        SerialPort1.Close()
        btnInit.Enabled = True

        btnClose.Enabled = False
        'GC.ReRegisterForFinalize(SerialPort1.BaseStream)
    End Sub

    'Private Sub SerialPort1_PinChanged(sender As Object, e As SerialPinChangedEventArgs) Handles SerialPort1.PinChanged
    '    If (SerialPort1.RtsEnable = False) Then
    '        SerialPort1.Close()
    '        btnInit.Enabled = True
    '        btnWrite.Enabled = False
    '        btnClose.Enabled = False
    '    End If
    'End Sub

    Private Sub SerialPort1_DataReceived(sender As Object, e As SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        ReceivedText(SerialPort1.ReadLine())
        'Send acknowledgement to hardware
        If ((m_StrResult <> "") And (m_IntMED > 0) And (m_IntMED < 441) And (SerialPort1.IsOpen = True)) Then
            If m_IntMEDFlag = 1 Then
                m_strTimeDate = m_strSED & Format(Now, "ddMMyyyHHmmss") & m_StrResult & m_IntMEDFlag & Format(m_IntMED, "00#") & Chr(62)
            ElseIf m_IntMEDFlag = 0 Then
                m_strTimeDate = m_strSED & Format(Now, "ddMMyyyHHmmss") & m_StrResult & m_IntMEDFlag & Chr(62)
            End If

            For ctn As Integer = 0 To (Len(m_strTimeDate) - 1)
                SerialPort1.Write(m_strTimeDate.Chars(ctn))
                SerialPort1.DiscardOutBuffer()
            Next
            If (m_strSED = "1") Then
                m_strSED = "0"
            End If
        End If
    End Sub

    Private Sub ReceivedText(ByVal [text] As String)
        If Me.rtbRec.InvokeRequired Then
            Dim x As New SetTextCallBack(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.lblUV.Text = ""
            Me.rtbRec.Text &= [text]
            Me.lblUV.Text &= [text].Split(",")(0) & Chr(10)
            Me.lblSED.Text = ""
            Me.lblSED.Text &= [text].Split(",")(1) & Chr(10)

            Me.rtbRec.Text &= [text]
            'Me.lblUV.Text &= [text]
            SerialPort1.DiscardInBuffer()
        End If
    End Sub

    Private Sub BtnMEDOvr_Click(sender As Object, e As EventArgs) Handles btnMEDOvr.Click
        'Manual override of MED
        If rtbMED.Text <> String.Empty Then
            Dim MED As Integer
            MED = rtbMED.Text
            If (Convert.ToInt32(MED) > 0 And Convert.ToInt32(MED) < 441) Then
                m_IntMED = MED
                m_IntMEDFlag = 1
                lblMED.Text = Format(m_IntMED, "00#") & m_IntMEDFlag
            End If
        End If

    End Sub


    Private Sub BtnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click
        If ((m_StrResult <> "") And (m_IntMED > 0) And (m_IntMED < 441) And (SerialPort1.IsOpen = True)) Then
            If m_IntMEDFlag = 1 Then
                m_strTimeDate = m_strSED & Format(Now, "ddMMyyyHHmmss") & m_StrResult & m_IntMEDFlag & Format(m_IntMED, "00#") & Chr(62)
            ElseIf m_IntMEDFlag = 0 Then
                m_strTimeDate = m_strSED & Format(Now, "ddMMyyyHHmmss") & m_StrResult & m_IntMEDFlag & Chr(62)
            End If
            lblDateTime.Text = m_strTimeDate

            For ctn As Integer = 0 To (Len(m_strTimeDate) - 1)
                SerialPort1.Write(m_strTimeDate.Chars(ctn))
                SerialPort1.DiscardOutBuffer()
            Next
            m_strSED = "0"
        End If
    End Sub

    Private Sub BtnResetSED_Click(sender As Object, e As EventArgs) Handles btnResetSED.Click
        m_strSED = "1"
    End Sub

End Class

