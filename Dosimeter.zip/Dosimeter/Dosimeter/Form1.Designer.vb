﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.cboQ1 = New System.Windows.Forms.ComboBox()
        Me.lblQ1 = New System.Windows.Forms.Label()
        Me.lblSum = New System.Windows.Forms.Label()
        Me.lblQ2 = New System.Windows.Forms.Label()
        Me.cboQ2 = New System.Windows.Forms.ComboBox()
        Me.btnResult = New System.Windows.Forms.Button()
        Me.lblQ3 = New System.Windows.Forms.Label()
        Me.cboQ3 = New System.Windows.Forms.ComboBox()
        Me.lblQ4 = New System.Windows.Forms.Label()
        Me.cboQ4 = New System.Windows.Forms.ComboBox()
        Me.lblQ5 = New System.Windows.Forms.Label()
        Me.cboQ5 = New System.Windows.Forms.ComboBox()
        Me.lblQ6 = New System.Windows.Forms.Label()
        Me.cboQ6 = New System.Windows.Forms.ComboBox()
        Me.lblQ7 = New System.Windows.Forms.Label()
        Me.cboQ7 = New System.Windows.Forms.ComboBox()
        Me.lblQ8 = New System.Windows.Forms.Label()
        Me.cboQ8 = New System.Windows.Forms.ComboBox()
        Me.lblQ9 = New System.Windows.Forms.Label()
        Me.cboQ9 = New System.Windows.Forms.ComboBox()
        Me.lblQ10 = New System.Windows.Forms.Label()
        Me.cboQ10 = New System.Windows.Forms.ComboBox()
        Me.chkTypeI = New System.Windows.Forms.CheckBox()
        Me.chkTypeII = New System.Windows.Forms.CheckBox()
        Me.chkTypeIII = New System.Windows.Forms.CheckBox()
        Me.chkTypeIV = New System.Windows.Forms.CheckBox()
        Me.chkTypeV = New System.Windows.Forms.CheckBox()
        Me.chkTypeVI = New System.Windows.Forms.CheckBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnInit = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.cboCOM = New System.Windows.Forms.ComboBox()
        Me.cboBaud = New System.Windows.Forms.ComboBox()
        Me.rtbRec = New System.Windows.Forms.RichTextBox()
        Me.lblRec = New System.Windows.Forms.Label()
        Me.lblMED = New System.Windows.Forms.Label()
        Me.btnSet = New System.Windows.Forms.Button()
        Me.rtbMED = New System.Windows.Forms.TextBox()
        Me.btnMEDOvr = New System.Windows.Forms.Button()
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.btnResetSED = New System.Windows.Forms.Button()
        Me.lblUV = New System.Windows.Forms.Label()
        Me.lblUVTag = New System.Windows.Forms.Label()
        Me.lblSEDTag = New System.Windows.Forms.Label()
        Me.lblSED = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'SerialPort1
        '
        '
        'cboQ1
        '
        Me.cboQ1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ1.FormattingEnabled = True
        Me.cboQ1.Items.AddRange(New Object() {"Light blue or green, grey", "Blue, green, grey", "Dark blue or green, light brown (hazel)", "Dark brown", "Brownish black"})
        Me.cboQ1.Location = New System.Drawing.Point(601, 59)
        Me.cboQ1.Name = "cboQ1"
        Me.cboQ1.Size = New System.Drawing.Size(305, 24)
        Me.cboQ1.TabIndex = 2
        '
        'lblQ1
        '
        Me.lblQ1.AutoSize = True
        Me.lblQ1.Location = New System.Drawing.Point(12, 59)
        Me.lblQ1.Name = "lblQ1"
        Me.lblQ1.Size = New System.Drawing.Size(223, 17)
        Me.lblQ1.TabIndex = 3
        Me.lblQ1.Text = "What are the colour of your eyes?"
        '
        'lblSum
        '
        Me.lblSum.AutoSize = True
        Me.lblSum.Location = New System.Drawing.Point(15, 500)
        Me.lblSum.Name = "lblSum"
        Me.lblSum.Size = New System.Drawing.Size(0, 17)
        Me.lblSum.TabIndex = 4
        '
        'lblQ2
        '
        Me.lblQ2.AutoSize = True
        Me.lblQ2.Location = New System.Drawing.Point(12, 99)
        Me.lblQ2.Name = "lblQ2"
        Me.lblQ2.Size = New System.Drawing.Size(386, 17)
        Me.lblQ2.TabIndex = 5
        Me.lblQ2.Text = "What is the colour of your hair (naturally and before aging)?"
        '
        'cboQ2
        '
        Me.cboQ2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ2.FormattingEnabled = True
        Me.cboQ2.Items.AddRange(New Object() {"Red", "Blonde", "Chestnut or dark blonde", "Dark brown", "Black"})
        Me.cboQ2.Location = New System.Drawing.Point(601, 99)
        Me.cboQ2.Name = "cboQ2"
        Me.cboQ2.Size = New System.Drawing.Size(305, 24)
        Me.cboQ2.TabIndex = 6
        '
        'btnResult
        '
        Me.btnResult.Location = New System.Drawing.Point(601, 494)
        Me.btnResult.Name = "btnResult"
        Me.btnResult.Size = New System.Drawing.Size(207, 23)
        Me.btnResult.TabIndex = 10
        Me.btnResult.Text = "Result"
        Me.btnResult.UseVisualStyleBackColor = True
        '
        'lblQ3
        '
        Me.lblQ3.AutoSize = True
        Me.lblQ3.Location = New System.Drawing.Point(12, 135)
        Me.lblQ3.Name = "lblQ3"
        Me.lblQ3.Size = New System.Drawing.Size(330, 17)
        Me.lblQ3.TabIndex = 11
        Me.lblQ3.Text = "What Is the colour of your skin (unexposed areas)?"
        '
        'cboQ3
        '
        Me.cboQ3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ3.FormattingEnabled = True
        Me.cboQ3.Items.AddRange(New Object() {"Pink", "Very Pale", "Light brown or olive", "Brown", "Dark brown"})
        Me.cboQ3.Location = New System.Drawing.Point(601, 135)
        Me.cboQ3.Name = "cboQ3"
        Me.cboQ3.Size = New System.Drawing.Size(305, 24)
        Me.cboQ3.TabIndex = 12
        '
        'lblQ4
        '
        Me.lblQ4.AutoSize = True
        Me.lblQ4.Location = New System.Drawing.Point(12, 171)
        Me.lblQ4.Name = "lblQ4"
        Me.lblQ4.Size = New System.Drawing.Size(282, 17)
        Me.lblQ4.TabIndex = 13
        Me.lblQ4.Text = "Do you have freckles on unexposed areas?"
        '
        'cboQ4
        '
        Me.cboQ4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ4.FormattingEnabled = True
        Me.cboQ4.Items.AddRange(New Object() {"Many", "Several", "Few", "Rare", "None"})
        Me.cboQ4.Location = New System.Drawing.Point(601, 171)
        Me.cboQ4.Name = "cboQ4"
        Me.cboQ4.Size = New System.Drawing.Size(305, 24)
        Me.cboQ4.TabIndex = 14
        '
        'lblQ5
        '
        Me.lblQ5.AutoSize = True
        Me.lblQ5.Location = New System.Drawing.Point(12, 207)
        Me.lblQ5.Name = "lblQ5"
        Me.lblQ5.Size = New System.Drawing.Size(466, 17)
        Me.lblQ5.TabIndex = 15
        Me.lblQ5.Text = "What happens to your skin if you stay in the sun for an extended period?"
        '
        'cboQ5
        '
        Me.cboQ5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ5.FormattingEnabled = True
        Me.cboQ5.Items.AddRange(New Object() {"Severe burns, blistering, peeling", "Moderate burns, blistering, peeling", "Burns sometimes followed by peeling", "Rare burns", "No burns"})
        Me.cboQ5.Location = New System.Drawing.Point(601, 207)
        Me.cboQ5.Name = "cboQ5"
        Me.cboQ5.Size = New System.Drawing.Size(305, 24)
        Me.cboQ5.TabIndex = 16
        '
        'lblQ6
        '
        Me.lblQ6.AutoSize = True
        Me.lblQ6.Location = New System.Drawing.Point(12, 242)
        Me.lblQ6.Name = "lblQ6"
        Me.lblQ6.Size = New System.Drawing.Size(254, 17)
        Me.lblQ6.TabIndex = 17
        Me.lblQ6.Text = "Do you turn brown after sun exposure?"
        '
        'cboQ6
        '
        Me.cboQ6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ6.FormattingEnabled = True
        Me.cboQ6.Items.AddRange(New Object() {"Never", "Rarely", "Sometimes", "Often", "Always"})
        Me.cboQ6.Location = New System.Drawing.Point(601, 242)
        Me.cboQ6.Name = "cboQ6"
        Me.cboQ6.Size = New System.Drawing.Size(305, 24)
        Me.cboQ6.TabIndex = 18
        '
        'lblQ7
        '
        Me.lblQ7.AutoSize = True
        Me.lblQ7.Location = New System.Drawing.Point(12, 276)
        Me.lblQ7.Name = "lblQ7"
        Me.lblQ7.Size = New System.Drawing.Size(156, 17)
        Me.lblQ7.TabIndex = 19
        Me.lblQ7.Text = "How brown do you get?"
        '
        'cboQ7
        '
        Me.cboQ7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ7.FormattingEnabled = True
        Me.cboQ7.Items.AddRange(New Object() {"Hardly or not at all", "Light tan", "Medium tan", "Dark tan", "Very dark tan"})
        Me.cboQ7.Location = New System.Drawing.Point(601, 276)
        Me.cboQ7.Name = "cboQ7"
        Me.cboQ7.Size = New System.Drawing.Size(305, 24)
        Me.cboQ7.TabIndex = 21
        '
        'lblQ8
        '
        Me.lblQ8.AutoSize = True
        Me.lblQ8.Location = New System.Drawing.Point(12, 308)
        Me.lblQ8.Name = "lblQ8"
        Me.lblQ8.Size = New System.Drawing.Size(215, 17)
        Me.lblQ8.TabIndex = 22
        Me.lblQ8.Text = "Is your face sensitive to the sun?"
        '
        'cboQ8
        '
        Me.cboQ8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ8.FormattingEnabled = True
        Me.cboQ8.Items.AddRange(New Object() {"Very sensitive", "Sensitive", "Mildly sensitive", "Resistant", "Very resistant"})
        Me.cboQ8.Location = New System.Drawing.Point(601, 308)
        Me.cboQ8.Name = "cboQ8"
        Me.cboQ8.Size = New System.Drawing.Size(305, 24)
        Me.cboQ8.TabIndex = 23
        '
        'lblQ9
        '
        Me.lblQ9.AutoSize = True
        Me.lblQ9.Location = New System.Drawing.Point(12, 340)
        Me.lblQ9.Name = "lblQ9"
        Me.lblQ9.Size = New System.Drawing.Size(150, 17)
        Me.lblQ9.TabIndex = 24
        Me.lblQ9.Text = "How often do you tan?"
        '
        'cboQ9
        '
        Me.cboQ9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ9.FormattingEnabled = True
        Me.cboQ9.Items.AddRange(New Object() {"Never", "Rarely", "Sometimes", "Often", "Always"})
        Me.cboQ9.Location = New System.Drawing.Point(601, 340)
        Me.cboQ9.Name = "cboQ9"
        Me.cboQ9.Size = New System.Drawing.Size(305, 24)
        Me.cboQ9.TabIndex = 25
        '
        'lblQ10
        '
        Me.lblQ10.AutoSize = True
        Me.lblQ10.Location = New System.Drawing.Point(12, 372)
        Me.lblQ10.Name = "lblQ10"
        Me.lblQ10.Size = New System.Drawing.Size(576, 17)
        Me.lblQ10.TabIndex = 26
        Me.lblQ10.Text = "When did you last expose your skin to the sun or artificial tannign sources (tann" &
    "ing beds)?"
        '
        'cboQ10
        '
        Me.cboQ10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQ10.FormattingEnabled = True
        Me.cboQ10.Items.AddRange(New Object() {"More than 3 months ago", "In the last 2-3 months", "In the last 1-2 months", "In the last week", "In the last day"})
        Me.cboQ10.Location = New System.Drawing.Point(601, 372)
        Me.cboQ10.Name = "cboQ10"
        Me.cboQ10.Size = New System.Drawing.Size(305, 24)
        Me.cboQ10.TabIndex = 27
        '
        'chkTypeI
        '
        Me.chkTypeI.AutoSize = True
        Me.chkTypeI.Location = New System.Drawing.Point(42, 440)
        Me.chkTypeI.Name = "chkTypeI"
        Me.chkTypeI.Size = New System.Drawing.Size(69, 21)
        Me.chkTypeI.TabIndex = 28
        Me.chkTypeI.Text = "Type I"
        Me.chkTypeI.UseVisualStyleBackColor = True
        '
        'chkTypeII
        '
        Me.chkTypeII.AutoSize = True
        Me.chkTypeII.Location = New System.Drawing.Point(156, 440)
        Me.chkTypeII.Name = "chkTypeII"
        Me.chkTypeII.Size = New System.Drawing.Size(72, 21)
        Me.chkTypeII.TabIndex = 29
        Me.chkTypeII.Text = "Type II"
        Me.chkTypeII.UseVisualStyleBackColor = True
        '
        'chkTypeIII
        '
        Me.chkTypeIII.AutoSize = True
        Me.chkTypeIII.Location = New System.Drawing.Point(285, 440)
        Me.chkTypeIII.Name = "chkTypeIII"
        Me.chkTypeIII.Size = New System.Drawing.Size(75, 21)
        Me.chkTypeIII.TabIndex = 30
        Me.chkTypeIII.Text = "Type III"
        Me.chkTypeIII.UseVisualStyleBackColor = True
        '
        'chkTypeIV
        '
        Me.chkTypeIV.AutoSize = True
        Me.chkTypeIV.Location = New System.Drawing.Point(409, 440)
        Me.chkTypeIV.Name = "chkTypeIV"
        Me.chkTypeIV.Size = New System.Drawing.Size(78, 21)
        Me.chkTypeIV.TabIndex = 31
        Me.chkTypeIV.Text = "Type IV"
        Me.chkTypeIV.UseVisualStyleBackColor = True
        '
        'chkTypeV
        '
        Me.chkTypeV.AutoSize = True
        Me.chkTypeV.Location = New System.Drawing.Point(531, 440)
        Me.chkTypeV.Name = "chkTypeV"
        Me.chkTypeV.Size = New System.Drawing.Size(75, 21)
        Me.chkTypeV.TabIndex = 32
        Me.chkTypeV.Text = "Type V"
        Me.chkTypeV.UseVisualStyleBackColor = True
        '
        'chkTypeVI
        '
        Me.chkTypeVI.AutoSize = True
        Me.chkTypeVI.Location = New System.Drawing.Point(652, 440)
        Me.chkTypeVI.Name = "chkTypeVI"
        Me.chkTypeVI.Size = New System.Drawing.Size(78, 21)
        Me.chkTypeVI.TabIndex = 33
        Me.chkTypeVI.Text = "Type VI"
        Me.chkTypeVI.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(830, 494)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(186, 23)
        Me.btnReset.TabIndex = 34
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnInit
        '
        Me.btnInit.Location = New System.Drawing.Point(981, 60)
        Me.btnInit.Name = "btnInit"
        Me.btnInit.Size = New System.Drawing.Size(75, 23)
        Me.btnInit.TabIndex = 35
        Me.btnInit.Text = "Init"
        Me.btnInit.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(1116, 59)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 36
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'cboCOM
        '
        Me.cboCOM.FormattingEnabled = True
        Me.cboCOM.Location = New System.Drawing.Point(935, 111)
        Me.cboCOM.Name = "cboCOM"
        Me.cboCOM.Size = New System.Drawing.Size(121, 24)
        Me.cboCOM.TabIndex = 37
        '
        'cboBaud
        '
        Me.cboBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBaud.FormattingEnabled = True
        Me.cboBaud.Items.AddRange(New Object() {"9600", "19200", "115200"})
        Me.cboBaud.Location = New System.Drawing.Point(1070, 111)
        Me.cboBaud.Name = "cboBaud"
        Me.cboBaud.Size = New System.Drawing.Size(121, 24)
        Me.cboBaud.TabIndex = 38
        '
        'rtbRec
        '
        Me.rtbRec.Location = New System.Drawing.Point(935, 188)
        Me.rtbRec.Name = "rtbRec"
        Me.rtbRec.Size = New System.Drawing.Size(301, 100)
        Me.rtbRec.TabIndex = 40
        Me.rtbRec.Text = ""
        '
        'lblRec
        '
        Me.lblRec.AutoSize = True
        Me.lblRec.Location = New System.Drawing.Point(932, 291)
        Me.lblRec.Name = "lblRec"
        Me.lblRec.Size = New System.Drawing.Size(59, 17)
        Me.lblRec.TabIndex = 42
        Me.lblRec.Text = "Receive"
        '
        'lblMED
        '
        Me.lblMED.AutoSize = True
        Me.lblMED.Location = New System.Drawing.Point(100, 500)
        Me.lblMED.Name = "lblMED"
        Me.lblMED.Size = New System.Drawing.Size(0, 17)
        Me.lblMED.TabIndex = 44
        '
        'btnSet
        '
        Me.btnSet.Location = New System.Drawing.Point(1035, 494)
        Me.btnSet.Name = "btnSet"
        Me.btnSet.Size = New System.Drawing.Size(180, 23)
        Me.btnSet.TabIndex = 45
        Me.btnSet.Text = "Set"
        Me.btnSet.UseVisualStyleBackColor = True
        '
        'rtbMED
        '
        Me.rtbMED.Location = New System.Drawing.Point(935, 372)
        Me.rtbMED.Name = "rtbMED"
        Me.rtbMED.Size = New System.Drawing.Size(100, 22)
        Me.rtbMED.TabIndex = 46
        '
        'btnMEDOvr
        '
        Me.btnMEDOvr.Location = New System.Drawing.Point(1070, 372)
        Me.btnMEDOvr.Name = "btnMEDOvr"
        Me.btnMEDOvr.Size = New System.Drawing.Size(129, 23)
        Me.btnMEDOvr.TabIndex = 47
        Me.btnMEDOvr.Text = "Set MED"
        Me.btnMEDOvr.UseVisualStyleBackColor = True
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.Location = New System.Drawing.Point(308, 500)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(0, 17)
        Me.lblDateTime.TabIndex = 48
        '
        'btnResetSED
        '
        Me.btnResetSED.Location = New System.Drawing.Point(1070, 414)
        Me.btnResetSED.Name = "btnResetSED"
        Me.btnResetSED.Size = New System.Drawing.Size(129, 23)
        Me.btnResetSED.TabIndex = 49
        Me.btnResetSED.Text = "Reset SED"
        Me.btnResetSED.UseVisualStyleBackColor = True
        '
        'lblUV
        '
        Me.lblUV.AutoSize = True
        Me.lblUV.Location = New System.Drawing.Point(788, 440)
        Me.lblUV.Name = "lblUV"
        Me.lblUV.Size = New System.Drawing.Size(24, 17)
        Me.lblUV.TabIndex = 50
        Me.lblUV.Text = "00"
        '
        'lblUVTag
        '
        Me.lblUVTag.AutoSize = True
        Me.lblUVTag.Location = New System.Drawing.Point(755, 440)
        Me.lblUVTag.Name = "lblUVTag"
        Me.lblUVTag.Size = New System.Drawing.Size(27, 17)
        Me.lblUVTag.TabIndex = 51
        Me.lblUVTag.Text = "UV"
        '
        'lblSEDTag
        '
        Me.lblSEDTag.AutoSize = True
        Me.lblSEDTag.Location = New System.Drawing.Point(842, 441)
        Me.lblSEDTag.Name = "lblSEDTag"
        Me.lblSEDTag.Size = New System.Drawing.Size(36, 17)
        Me.lblSEDTag.TabIndex = 52
        Me.lblSEDTag.Text = "SED"
        '
        'lblSED
        '
        Me.lblSED.AutoSize = True
        Me.lblSED.Location = New System.Drawing.Point(890, 440)
        Me.lblSED.Name = "lblSED"
        Me.lblSED.Size = New System.Drawing.Size(16, 17)
        Me.lblSED.TabIndex = 53
        Me.lblSED.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1258, 537)
        Me.Controls.Add(Me.lblSED)
        Me.Controls.Add(Me.lblSEDTag)
        Me.Controls.Add(Me.lblUVTag)
        Me.Controls.Add(Me.lblUV)
        Me.Controls.Add(Me.btnResetSED)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.btnMEDOvr)
        Me.Controls.Add(Me.rtbMED)
        Me.Controls.Add(Me.btnSet)
        Me.Controls.Add(Me.lblMED)
        Me.Controls.Add(Me.lblRec)
        Me.Controls.Add(Me.rtbRec)
        Me.Controls.Add(Me.cboBaud)
        Me.Controls.Add(Me.cboCOM)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnInit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.chkTypeVI)
        Me.Controls.Add(Me.chkTypeV)
        Me.Controls.Add(Me.chkTypeIV)
        Me.Controls.Add(Me.chkTypeIII)
        Me.Controls.Add(Me.chkTypeII)
        Me.Controls.Add(Me.chkTypeI)
        Me.Controls.Add(Me.cboQ10)
        Me.Controls.Add(Me.lblQ10)
        Me.Controls.Add(Me.cboQ9)
        Me.Controls.Add(Me.lblQ9)
        Me.Controls.Add(Me.cboQ8)
        Me.Controls.Add(Me.lblQ8)
        Me.Controls.Add(Me.cboQ7)
        Me.Controls.Add(Me.lblQ7)
        Me.Controls.Add(Me.cboQ6)
        Me.Controls.Add(Me.lblQ6)
        Me.Controls.Add(Me.cboQ5)
        Me.Controls.Add(Me.lblQ5)
        Me.Controls.Add(Me.cboQ4)
        Me.Controls.Add(Me.lblQ4)
        Me.Controls.Add(Me.cboQ3)
        Me.Controls.Add(Me.lblQ3)
        Me.Controls.Add(Me.btnResult)
        Me.Controls.Add(Me.cboQ2)
        Me.Controls.Add(Me.lblQ2)
        Me.Controls.Add(Me.lblSum)
        Me.Controls.Add(Me.lblQ1)
        Me.Controls.Add(Me.cboQ1)
        Me.Name = "Form1"
        Me.Text = "Dosimeter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents cboQ1 As ComboBox
    Friend WithEvents lblQ1 As Label
    Friend WithEvents lblSum As Label
    Friend WithEvents lblQ2 As Label
    Friend WithEvents cboQ2 As ComboBox
    Friend WithEvents btnResult As Button
    Friend WithEvents lblQ3 As Label
    Friend WithEvents cboQ3 As ComboBox
    Friend WithEvents lblQ4 As Label
    Friend WithEvents cboQ4 As ComboBox
    Friend WithEvents lblQ5 As Label
    Friend WithEvents cboQ5 As ComboBox
    Friend WithEvents lblQ6 As Label
    Friend WithEvents cboQ6 As ComboBox
    Friend WithEvents lblQ7 As Label
    Friend WithEvents cboQ7 As ComboBox
    Friend WithEvents lblQ8 As Label
    Friend WithEvents cboQ8 As ComboBox
    Friend WithEvents lblQ9 As Label
    Friend WithEvents cboQ9 As ComboBox
    Friend WithEvents lblQ10 As Label
    Friend WithEvents cboQ10 As ComboBox
    Friend WithEvents chkTypeI As CheckBox
    Friend WithEvents chkTypeII As CheckBox
    Friend WithEvents chkTypeIII As CheckBox
    Friend WithEvents chkTypeIV As CheckBox
    Friend WithEvents chkTypeV As CheckBox
    Friend WithEvents chkTypeVI As CheckBox
    Friend WithEvents btnReset As Button
    Friend WithEvents btnInit As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents cboCOM As ComboBox
    Friend WithEvents cboBaud As ComboBox
    Friend WithEvents rtbRec As RichTextBox
    Friend WithEvents lblRec As Label
    Friend WithEvents lblMED As Label
    Friend WithEvents btnSet As Button
    Friend WithEvents rtbMED As TextBox
    Friend WithEvents btnMEDOvr As Button
    Friend WithEvents lblDateTime As Label
    Friend WithEvents btnResetSED As Button
    Friend WithEvents lblUV As Label
    Friend WithEvents lblUVTag As Label
    Friend WithEvents lblSEDTag As Label
    Friend WithEvents lblSED As Label
End Class
